-- Server Side City Sluggers
-- Test Queries

-- Customers and their Order Status
/*use customers;
select orderdata.order_id, cfn, cln, status_desc
from customer
	join orders.orderdata on customer.cid = orders.orderdata.cid 
		join orders.orderstatus on orders.orderdata.order_id = orders.orderstatus.order_id
			join orders.currstatus on orders.orderstatus.statusID = orders.currstatus.statusID
order by order_id*/

-- Customers and their Payment Methods
/*select cfn, cln, method_desc
from customer
	join payments.customerpaymentmethod on customer.cid = payments.customerpaymentmethod.cid
		join payments.paymentmethod on payments.customerpaymentmethod.method_id = payments.paymentmethod.method_id
order by cln*/

-- Customers and their Product Order w/Given Payment Method
/*select cfn, cln, orderdata.order_id, order_date, prod_name, price,qty, (price*qty) as 'Cost', method_desc
from customer
	join orders.orderdata on customer.cid = orders.orderdata.cid
		join orders.lineitem on orders.orderdata.order_id = orders.lineitem.order_id
			join products.product on orders.lineitem.pid = products.product.pid
				join payments.customerpaymentmethod on customer.cid = payments.customerpaymentmethod.cid
					join payments.paymentmethod on payments.paymentmethod.method_id = payments.customerpaymentmethod.method_id 
order by cln*/